--game

addappid(393380)
addappid(393381, 1, "d11ff0e6b7d56d9c48173256141f75daf1a14f85f6aac9e09d45d05ef7ef935d")
setManifestid(393381, "4265928685563316830", 0)


--dlc

addappid(421270)
addappid(421271)
addappid(421272)
addappid(421273)
addappid(421274)
addappid(421275)
addappid(422950)
addappid(422960)
addappid(422961)
addappid(2222340)
addappid(2222341)
addappid(2222342)
addappid(2417350)
addappid(2417351)
addappid(2521990)
addappid(2522000)
addappid(2584870)
addappid(2598380)
addappid(2820320)
addappid(2826950)
addappid(2974490)
addappid(3165850)
addappid(3165860)