-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(636480)
addappid(636481, 1, "85a0ec71b9f6fb33c36056ce85f0937f8465b590f8cacb1d7eef63d2d9a0061c")
setManifestid(636481, "513840834472907355", 0)