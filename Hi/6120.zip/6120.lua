-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(6120)
addappid(6121, 1, "6ed17075d0fa3d2a0d7a26e7b55b3515640c2cc3aedb9bb676cfa5ffde3a8411")
setManifestid(6121, "8359087293181816026", 0)