-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(102840)
addappid(102841, 1, "587dc4fdaaf24f4ad2e33f9a1ba61025351157eede5dc3c0a9f0bed831a488e6")
setManifestid(102841, "6337282187118349599", 0)